# Slot-Machine-Game
This is a casino slot game based on matching the emojis.
